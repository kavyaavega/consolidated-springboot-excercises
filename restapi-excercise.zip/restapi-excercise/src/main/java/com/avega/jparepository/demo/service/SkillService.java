package com.avega.jparepository.demo.service;

import java.util.List;
import java.util.Optional;

import com.avega.jparepository.demo.model.Skill;


public interface SkillService {
	
	List<Skill> findAll();
	Skill addSkill(Skill skill);
	public void deleteSkill(Skill skill);
	public void updateSkill(Skill skill);
	public Optional<Skill> findBySkillId(String skillId);

}

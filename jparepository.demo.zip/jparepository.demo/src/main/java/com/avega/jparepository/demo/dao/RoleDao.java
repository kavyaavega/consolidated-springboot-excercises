package com.avega.jparepository.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.avega.jparepository.demo.model.Role;

public interface RoleDao extends JpaRepository<Role, String> {

}

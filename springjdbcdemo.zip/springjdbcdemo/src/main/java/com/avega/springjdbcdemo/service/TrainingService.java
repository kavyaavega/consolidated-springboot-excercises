package com.avega.springjdbcdemo.service;

import java.util.List;
import java.util.Optional;

import com.avega.springjdbcdemo.exception.TrainingNotFoundException;
import com.avega.springjdbcdemo.model.Training;


public interface TrainingService {
	
	List<Training> findAllTrainingDetails();
	//Optional<Training>  findTrainingById(int id) throws TrainingNotFoundException;
	int createTraining(Training training);
	int editTraining(Training training);
	Training findTrainingByid(int id);

}

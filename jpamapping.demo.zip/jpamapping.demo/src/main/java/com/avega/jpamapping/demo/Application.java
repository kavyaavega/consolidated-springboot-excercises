package com.avega.jpamapping.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.avega.jpamapping.dao.EmployeeDao;
import com.avega.jpamapping.service.EmployeeService;
import com.avega.jpamapping.serviceimpl.EmployeeServiceImpl;

@EnableJpaRepositories
@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		ApplicationContext ctn = SpringApplication.run(Application.class, args);
		EmployeeService employeeService =(EmployeeService) ctn.getBean(EmployeeServiceImpl.class);
		System.out.println(employeeService.findAll());
	}

}

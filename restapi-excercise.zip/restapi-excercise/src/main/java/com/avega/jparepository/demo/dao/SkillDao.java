package com.avega.jparepository.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avega.jparepository.demo.model.Skill;

//@Repository
public interface SkillDao extends JpaRepository<Skill, String> {

}

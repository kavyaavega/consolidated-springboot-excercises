package com.example.mvcapp.utilities;

import org.springframework.web.client.RestTemplate;

public class RestTemplates {
	RestTemplate restTemplate;
	
	public RestTemplates() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RestTemplates(RestTemplate restTemplate) {
		super();
		this.restTemplate = restTemplate;
	}

	public RestTemplate getRestTemplate() {
		return restTemplate;
	}

	public void setRestTemplate(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}
	
	
}

package com.avega.jparepository.demo.service;

import java.util.List;
import java.util.Optional;

import com.avega.jparepository.demo.model.Department;
public interface DepartmentService {
	
	List<Department> findAll();
	Department addDepartment(Department department);
	public void deleteDepartment(Department department);
	public void updateDepartment(Department department);
	public Optional<Department> findByDepartmentId(String departmentId);

}

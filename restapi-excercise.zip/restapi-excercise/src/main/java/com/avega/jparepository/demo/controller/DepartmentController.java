//package com.avega.jparepository.demo.controller;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.avega.jpa.testdemo.model.Blog;
//import com.avega.jpa.testdemo.response.Response;
//import com.avega.jparepository.demo.model.Department;
//import com.avega.jparepository.demo.service.DepartmentService;
//
//
//
//@RestController
//public class DepartmentController {
//	
//	@Autowired
//	DepartmentService departmentService;
//	
////	@PostMapping("/departments")
////	public ResponseEntity<Response> addDepartments(){
////		List<Department> departmentList = departmentService.findAll();
////		
////		Response response = new Response();
////		
////	}
//
//}

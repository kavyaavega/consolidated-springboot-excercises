package com.avega.jparepository.demo.model;


import java.time.LocalDate;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Table(name="employee_tbl")
public class Employee {
	@Id
	@Column(name="emp_id")
	private String empId;
	
	@Column(name="employee_name")
	private String employeeName;
	
	@Column(name="doj")
	private LocalDate doj;
	
	@Column(name="designation")
	private String designation;
	
	@ManyToOne
	@JoinColumn(name="department_id")
	private Department department;
	
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name ="employee_role_tbl",
	joinColumns = @JoinColumn(referencedColumnName = "emp_id"),
	inverseJoinColumns = @JoinColumn(referencedColumnName = "role_id"))
	List<Role>roles;
	
	@ManyToMany
	@JoinTable(name ="employee_skill_tbl",
	joinColumns = @JoinColumn(referencedColumnName = "emp_id"),
	inverseJoinColumns = @JoinColumn(referencedColumnName = "skill_id"))
	List<Skill>skills;
	
	
	
	

}

package com.avega.jparepository.demo.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Table(name="department_tbl")
public class Department {
    
	@Id
	@Column(name="department_id")
	private String departmentId;
	
	@Column(name="department_name")
	private  String departmentName;
	
	@Column(name="department_location")
	private String departmentLocation;
	
	@Column(name="department_head")
	private String departmentHead;
	
	@OneToMany(mappedBy ="department")
	List<Employee>employees;
	
}

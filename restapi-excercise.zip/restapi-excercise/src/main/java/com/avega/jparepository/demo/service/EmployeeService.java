package com.avega.jparepository.demo.service;

import java.util.List;
import java.util.Optional;

import com.avega.jparepository.demo.model.Employee;


public interface EmployeeService {
	List<Employee> findAll();
	Employee addEmployee(Employee employee);
	public void deleteEmployee(Employee employee);
	public void updateEmployee(Employee employee);
	public Optional<Employee> findByEmpId(String empId);
	public void allocateEmployeeToRole(String empId,String roleId);

}

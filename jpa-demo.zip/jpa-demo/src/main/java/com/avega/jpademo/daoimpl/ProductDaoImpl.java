package com.avega.jpademo.daoimpl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.avega.jpademo.dao.ProductDao;
import com.avega.jpademo.model.Product;


@Repository
public class ProductDaoImpl implements ProductDao{
	
	@Autowired
	EntityManager entityManager;
	
	@Transactional
	@Override
	public Product save(Product product) {
		entityManager.persist(product);
		return product;
	}

	@Override
	public Product retrive(String productCode) {
		return entityManager.find(Product.class, productCode);
	}

	@Override
	public List<Product> fetchAllProducts() {
		@SuppressWarnings("unchecked")
		List<Product> products=entityManager.createQuery("from Product p",Product.class).getResultList();
		return products;
	}

	@Transactional
	@Override
	public Product updateProduct(Product product) {
		Product prod=entityManager.find(Product.class,product.getProductCode());
		prod.setProdDesc(product.getProdDesc());
		prod.setCategoryCode(product.getCategoryCode());
		prod.setPrice(product.getPrice());
		prod.setQtyOnHand(product.getQtyOnHand());
		return entityManager.merge(prod);
	}

	@Transactional
	@Override
	public boolean deleteProduct(String productCode) {
		boolean flag=false;
		Product prod=entityManager.find(Product.class,productCode );
		entityManager.remove(prod);
		if(entityManager.find(Product.class,productCode )==null)
			flag=true;
		return flag;
	}

}

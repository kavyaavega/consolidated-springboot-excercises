package com.avega.springjdbcdemo.dao;

import java.util.List;
import java.util.Optional;

import com.avega.springjdbcdemo.exception.TrainingNotFoundException;
import com.avega.springjdbcdemo.model.Training;


public interface TrainingDao {
	
	List<Training> getAllTrainingDetails();
	//Optional<Training> getTrainingDetailById(int id) throws TrainingNotFoundException;
	int addTraining(Training training);
	int updateTraining(Training training);
	//int deleteTraining(Training training);
	
	Training getTrainingByid(int id) throws TrainingNotFoundException;
	

}

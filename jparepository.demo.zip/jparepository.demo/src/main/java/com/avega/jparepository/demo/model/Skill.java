package com.avega.jparepository.demo.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;



@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Table(name="skill")
public class Skill {
	
	@Id
	@Column(name="skill_id")
	private String skillId;
	
	@Column(name="skill_name")
	private String skillName;

}

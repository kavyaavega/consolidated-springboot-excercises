package com.avega.jpamapping.model;


import java.util.Date;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@ToString
@Table(name="training")
public class Training {
	@Id
	private String trainingId;
	
	private String description;
	
	private Date startDate;
	
	private Date endDate;
	
	private String requestorId;
	
	@OneToOne
	private Employee employee;
	
	private Set<Skill> skills;
	
	
	
	

}

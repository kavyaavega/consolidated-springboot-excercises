package com.avega.jpademo.dao;

import java.util.List;

import com.avega.jpademo.model.Product;

public interface ProductDao {
	
	Product save(Product product);
	Product retrive(String productCode);
	List<Product> fetchAllProducts();
	Product updateProduct(Product product);
	boolean deleteProduct(String productCode);

}

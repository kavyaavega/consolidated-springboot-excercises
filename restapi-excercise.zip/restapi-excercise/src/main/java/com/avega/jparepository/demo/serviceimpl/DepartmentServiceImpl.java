package com.avega.jparepository.demo.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.avega.jparepository.demo.dao.DepartmentDao;
import com.avega.jparepository.demo.model.Department;
import com.avega.jparepository.demo.service.DepartmentService;

@Service
public class DepartmentServiceImpl implements DepartmentService {
	
	DepartmentDao departmentDao;

	@Override
	public List<Department> findAll() {
		return departmentDao.findAll();
	}

	@Override
	public Department addDepartment(Department department) {
		System.out.println("Inside add method");
		return departmentDao.save(department);
	}

	@Override
	public void deleteDepartment(Department department) {
		departmentDao.delete(department);
	}

	@Override
	public void updateDepartment(Department department) {
		Optional<Department> isDepartment = findByDepartmentId(department.getDepartmentId());
		if(isDepartment.isPresent()) {
			isDepartment.get().setDepartmentName(department.getDepartmentName());
			isDepartment.get().setDepartmentLocation(department.getDepartmentLocation());
			addDepartment(isDepartment.get());
		}
		
	}

	@Override
	public Optional<Department> findByDepartmentId(String departmentId) {
		return departmentDao.findById(departmentId);
	}

}

package com.avega.jparepository.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.avega.jparepository.demo.model.Employee;

public interface EmployeeDao extends JpaRepository<Employee, String> {
	

}

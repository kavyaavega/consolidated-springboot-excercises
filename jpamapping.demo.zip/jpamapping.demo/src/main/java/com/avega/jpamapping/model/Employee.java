package com.avega.jpamapping.model;


import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.JoinColumn;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Table(name="employee")
public class Employee {
	@Id
	@Column(name="emp_id")
	private String empId;
	
	@Column(name="employee_name",nullable=false)
	private String employeeName;
	
	@Column(name="doj")
	private Date doj;
	
	@Column(name="designation",nullable=false)
	private String designation;
	
	@Column(name="department",nullable=false)
	private String department;
	
	@ManyToMany(fetch=FetchType.EAGER)
	@JoinTable(name = "employee_skills",
	joinColumns = @JoinColumn(referencedColumnName = "emp_id"),
	inverseJoinColumns = @JoinColumn(referencedColumnName = "skill_id"))
	private Set<Skill> skill;
	
	//@OneToMany(mappedBy="employee")
	//private List<Allocation> training;
	

}

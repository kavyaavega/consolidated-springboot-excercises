package com.avega.springjdbcdemo.mapper;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.avega.springjdbcdemo.model.Training;

public class TrainingMapper implements RowMapper<Training> {

	@Override
	public Training mapRow(ResultSet rs, int rowNum) throws SQLException {
		Training training = new Training();
		
		training.setId(rs.getInt(1));
		training.setDescription(rs.getString(2));
		training.setStartDate(rs.getDate(3).toLocalDate());
		training.setEndDate(rs.getDate(4).toLocalDate());
		training.setRequestor_id(rs.getInt(5));
		training.setTraineeEmployee(rs.getInt(6));
		training.setSkillId(rs.getInt(6));
		
		return training;
	}

}

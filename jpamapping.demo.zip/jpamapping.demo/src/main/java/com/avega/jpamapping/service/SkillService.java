package com.avega.jpamapping.service;

public interface SkillService {

}

package com.avega.jpamapping.daoimpl;

public class SkillDaoImpl {

}

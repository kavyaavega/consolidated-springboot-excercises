package com.avega.jparepository.demo;

import java.sql.Date;
import java.time.LocalDate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.avega.jparepository.demo.model.Department;
import com.avega.jparepository.demo.model.Employee;
import com.avega.jparepository.demo.model.Role;
import com.avega.jparepository.demo.model.Skill;
import com.avega.jparepository.demo.service.DepartmentService;
import com.avega.jparepository.demo.service.EmployeeService;
import com.avega.jparepository.demo.service.RoleService;
import com.avega.jparepository.demo.service.SkillService;

@SpringBootApplication
@EnableJpaRepositories
public class Application {

	public static void main(String[] args) {
		ApplicationContext ctn =SpringApplication.run(Application.class, args);
		//EmployeeService employeeService = ctn.getBean(EmployeeService.class);
		//RoleService roleService = ctn.getBean(RoleService.class);
		//SkillService skillService = ctn.getBean(SkillService.class);
		//DepartmentService departmentService = ctn.getBean(DepartmentService.class);
		
		//employeeService.addEmployee(new Employee("E101","Kavya",LocalDate.of(2023, 01, 03),"developer","IT", new Department(null),null));
		//employeeService.addEmployee(new Employee("E102","Lingesh",LocalDate.of(2023, 01, 04),"developer","IT",null,null));
		//employeeService.addEmployee(new Employee("E103","Gokul",LocalDate.of(2023, 01, 05),"Testor","IT",null,null));
		
		//roleService.addRole(new Role("R01","developer",null));
		//roleService.addRole(new Role("R02","developer",null));
		//roleService.addRole(new Role("R03","testor",null));
		
//		skillService.addSkill(new Skill("SK01","Java"));
//		skillService.addSkill(new Skill("SK02","SQL"));
//		skillService.addSkill(new Skill("SK03","C++"));
		
		//departmentService.addDepartment(new Department("D101","It department","bangalore","satish",null));
		//departmentService.addDepartment(new Department("D102","Cs department","mysore","naveen",null));
		//departmentService.addDepartment(new Department("D103","EEE department","chennai","arun",null));
		//departmentService.addDepartment(new Department("D104","EC department","hyderabad","vel",null));
		//employeeService.allocateEmployeeToRole("E101", "R01");
		
		
	}

}

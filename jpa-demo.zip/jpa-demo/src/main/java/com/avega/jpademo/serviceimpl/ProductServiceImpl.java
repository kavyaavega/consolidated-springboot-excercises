package com.avega.jpademo.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.avega.jpademo.dao.ProductDao;
import com.avega.jpademo.model.Product;
import com.avega.jpademo.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {
	
    ProductDao productDao;
	
	@Autowired
	public ProductServiceImpl(ProductDao productDao) {
		this.productDao=productDao;
	}

	@Override
	public Product add(Product product) {
		return productDao.save(product);
	}

	@Override
	public Product retriveByProductCode(String productCode) {
		return productDao.retrive(productCode);
	}

	@Override
	public List<Product> findAllProducts() {
		return productDao.fetchAllProducts();
	}

	@Override
	public Product editProduct(Product product) {
		return productDao.updateProduct(product);
	}

	@Override
	public boolean removeProduct(String productCode) {
		return productDao.deleteProduct(productCode);
	}

}

package com.avega.jparepository.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avega.jparepository.demo.model.Employee;

//@Repository
public interface EmployeeDao extends JpaRepository<Employee, String> {
	

}

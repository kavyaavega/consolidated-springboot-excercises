package com.avega.jparepository.demo.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.avega.jparepository.demo.dao.SkillDao;
import com.avega.jparepository.demo.model.Skill;
import com.avega.jparepository.demo.service.SkillService;

@Service
public class SkillServiceImpl implements SkillService {

	SkillDao skillDao;
	
	@Override
	public List<Skill> findAll() {
		return skillDao.findAll();
	}

	@Override
	public Skill addSkill(Skill skill) {
		return skillDao.save(skill);
	}

	@Override
	public void deleteSkill(Skill skill) {
		skillDao.delete(skill);
	}

	@Override
	public void updateSkill(Skill skill) {
		Optional<Skill> isSkill = findBySkillId(skill.getSkillId());
		if(isSkill.isPresent()) {
			isSkill.get().setSkillName(skill.getSkillName());
			addSkill(isSkill.get());	
		}
		
	}

	@Override
	public Optional<Skill> findBySkillId(String skillId) {
		return skillDao.findById(skillId);
	}

}

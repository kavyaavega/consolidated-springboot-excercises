package com.avega.jpa.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.avega.jpa.dao.EmployeeDao;
import com.avega.jpa.dao.RoleDao;
import com.avega.jpa.entity.Employee;
import com.avega.jpa.entity.Role;
import com.avega.jpa.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	private EmployeeDao employeeDao;
	private RoleDao roleDao;

	@Autowired
	public EmployeeServiceImpl(EmployeeDao employeeDao, RoleDao roleDao) {
		this.employeeDao = employeeDao;
		this.roleDao = roleDao;
	}

	@Override
	public List<Employee> findAllEmployees() {
		return employeeDao.findAll();
	}

	@Override
	public Optional<Employee> findByEmployeeId(String employeeId) {
		return employeeDao.findById(employeeId);
	}

	@Override
	public Employee addEmployee(Employee employee) {
		return employeeDao.save(employee);
	}

	@Override
	public void updateEmployee(Employee employee) {
		Optional<Employee> isEmployee = findByEmployeeId(employee.getEmpId());
		if (isEmployee.isPresent()) {
			isEmployee.get().setEmpName(employee.getEmpName());
			isEmployee.get().setDoj(employee.getDoj());
			isEmployee.get().setDepartment(employee.getDepartment());
			isEmployee.get().setDesignation(employee.getDesignation());
			isEmployee.get().setPassword(employee.getPassword());
			isEmployee.get().setEmailId(employee.getEmailId());
			addEmployee(isEmployee.get());
		}

	}

	@Override
	public void deleteEmployee(Employee employee) {
		employeeDao.delete(employee);
	}

	@Override
	public void allocateRoleForEmployee(String employeeId, String roleId) {

		Optional<Employee> optionalEmployee = findByEmployeeId(employeeId);
		if (optionalEmployee.isPresent()) {
			Employee employee = optionalEmployee.get();
			Optional<Role> optionalRole = this.roleDao.findById(roleId);
			if (optionalRole.isPresent()) {
				Role role = optionalRole.get();
				List<Role> roles = employee.getRoles();
				roles.add(role);
				employee.setRoles(roles);
				employeeDao.save(employee);
			}

		}

	}

}

package com.example.mvcapp.model;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class Lawyer {
	
	@Id
	@GeneratedValue(strategy= GenerationType.SEQUENCE)
	private int lawyerId;
	
	private String firstName;
	
	private String LastName;
	
	private String phone;
	
	private String specialty;
	
	@OneToMany(mappedBy="lawyer")
	private Set<Appointment> lawyerAppointmentSet;

	public Lawyer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Lawyer(String firstName, String lastName, String phone, String specialty) {
		super();
		this.firstName = firstName;
		LastName = lastName;
		this.phone = phone;
		this.specialty = specialty;
	}

	public int getLawyerId() {
		return lawyerId;
	}

	public void setLawyerId(int lawyerId) {
		this.lawyerId = lawyerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getSpecialty() {
		return specialty;
	}

	public void setSpecialty(String specialty) {
		this.specialty = specialty;
	}

	public Set<Appointment> getLawyerAppointmentSet() {
		return lawyerAppointmentSet;
	}

	public void setLawyerAppointmentSet(Set<Appointment> lawyerAppointmentSet) {
		this.lawyerAppointmentSet = lawyerAppointmentSet;
	}

}

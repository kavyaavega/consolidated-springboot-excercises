package com.avega.jpamapping.service;

import java.util.List;

import com.avega.jpamapping.model.Employee;

public interface EmployeeService {
	
	List<Employee> findAll();
	

}

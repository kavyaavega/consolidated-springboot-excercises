package com.avega.jpa.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.avega.jpa.entity.Employee;
import com.avega.jpa.entity.Role;
import com.avega.jpa.service.EmployeeService;



@Service
public class CustomUserDetailsService implements UserDetailsService {
	
	@Autowired
	EmployeeService employeeService;
	
	public EmployeeService getEmployeeService() {
		return employeeService;
	}

	public void setEmployeeService(EmployeeService employeeService) {
		this.employeeService = employeeService;
	}

	@Override
	public UserDetails loadUserByUsername(String empId) throws UsernameNotFoundException {
		Optional<Employee> optionalEmp = employeeService.findByEmployeeId(empId);
		if(!optionalEmp.isPresent()) {
			System.out.println("User Not Found");
			return null;
		}
		Employee data = optionalEmp.get();
		System.out.println(data);
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		return new User(data.getEmpId(), encoder.encode(data.getPassword()), true, true, true, true, getGrantedAuthorities(data));
	}
	
	private List<GrantedAuthority> getGrantedAuthorities(Employee userData){
		List<GrantedAuthority> roles = new ArrayList<GrantedAuthority>();
		for(Role userRole : userData.getRoles()){
			roles.add(new SimpleGrantedAuthority( userRole.getRoleName()));
		}
		return roles;
	}


}

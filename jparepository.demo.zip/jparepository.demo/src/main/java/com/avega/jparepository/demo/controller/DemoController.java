package com.avega.jparepository.demo.controller;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.avega.jparepository.demo.model.Employee;
import com.avega.jparepository.demo.model.Role;
import com.avega.jparepository.demo.properties.LocalDateProperty;
import com.avega.jparepository.demo.service.EmployeeService;
import com.avega.jparepository.demo.service.RoleService;
import com.avega.jparepository.demo.service.SkillService;

@Controller
public class DemoController {
	
	@Autowired
    EmployeeService employeeService;
    
    @Autowired
    RoleService roleService;
    
    @Autowired
    SkillService skillService;
    
    @InitBinder
    public void employeebinder(WebDataBinder webDataBinder) {
    	webDataBinder.registerCustomEditor(LocalDate.class, "doj",new LocalDateProperty());
    }
	
	@RequestMapping(value = "/home", method=RequestMethod.GET)
	public String getAllEmployees() {
	return "home";
	}
	
	@RequestMapping(value = "/details", method=RequestMethod.GET)
	public String getAllEmployees(Model model) {
		model.addAttribute("employees",employeeService.findAll());
	return "details";
	}
	
	@RequestMapping(value = "/create", method=RequestMethod.GET)
	public String addEmployee(Model model) {
		model.addAttribute(new Employee());
	return "create";
	}
	
	@RequestMapping(value = "/update", method=RequestMethod.GET)
	public String updateEmployee(@RequestParam String empId, Model model) {
		Optional<Employee> optEmployee = employeeService.findByEmpId(empId);
		if(optEmployee.isPresent()) 
			model.addAttribute(optEmployee.get());
			return "update";
		}
	
	
	@RequestMapping(value = "/save", method=RequestMethod.POST)
	public String saveEmployee(@ModelAttribute("employee")Employee employee) {
		employeeService.addEmployee(employee);
	return "redirect:/details";
	}
	
	@RequestMapping(value = "/update-save", method=RequestMethod.POST)
	public String saveUpdateEmployee(@ModelAttribute("employee")Employee employee) {
		employeeService.updateEmployee(employee);
	return "redirect:/details";
	}
	
	@RequestMapping(value = "/delete/{empId}")
	public String deleteEmployee(@PathVariable String empId) {
		Optional<Employee> optionalEmployee = employeeService.findByEmpId(empId);
		if(optionalEmployee.isPresent())
		employeeService.deleteEmployee(optionalEmployee.get());
	return "redirect:/details";
	}
	
	//to get role details
	@RequestMapping(value = "/roledetails", method=RequestMethod.GET)
	public String getAllRoles(Model model) {
		model.addAttribute("roles",roleService.findAll());
	return "roledetails";
	}
	
	@RequestMapping(value = "/createrole", method=RequestMethod.GET)
	public String addRoles(Model model) {
		model.addAttribute(new Role());
	return "createrole";
	}
	
	@RequestMapping(value = "/save-role", method=RequestMethod.POST)
	public String saveRole(@ModelAttribute("role")Role role) {
		roleService.addRole(role);
	return "redirect:/roledetails";
	}
	
	@RequestMapping(value = "/roleupdate", method=RequestMethod.GET)
	public String updateRole(@RequestParam String roleId, Model model) {
		Optional<Role> optRole = roleService.findByRoleId(roleId);
		if(optRole.isPresent()) 
			model.addAttribute(optRole.get());
			return "roleupdate";
		}
	
	@RequestMapping(value = "/roleupdate-save", method=RequestMethod.POST)
	public String saveUpdateRole(@ModelAttribute("role")Role role) {
		roleService.updateRole(role);
	        return "redirect:/roledetails";
	}
	
	@RequestMapping(value = "/roledelete/{roleId}")
	public String deleteRole(@PathVariable String roleId) {
		Optional<Role> optionalRole = roleService.findByRoleId(roleId);
		if(optionalRole.isPresent())
			roleService.deleteRole(optionalRole.get());
	       return "redirect:/roledetails";
	}
	
	//to get skill details
	
	@RequestMapping(value = "/skilldetails", method=RequestMethod.GET)
	public String getAllSkills(Model model) {
		model.addAttribute("skill",skillService.findAll());
	return "skilldetails";
	}
	
	


}

package com.avega.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import com.avega.jpa.mvc.config.AppSecurityConfig;
import com.avega.jpa.service.EmployeeService;




@SpringBootApplication(exclude= {SecurityAutoConfiguration.class})
@Import ({AppSecurityConfig.class})
@EnableJpaRepositories
public class JpaProjectApplication {

	public static void main(String[] args) {
		ApplicationContext ctn = SpringApplication.run(JpaProjectApplication.class, args);
		
//		EmployeeService employeeService = ctn.getBean(EmployeeService.class);
//		employeeService.allocateRoleForEmployee("E101", "R101");
 
	}

}

package com.avega.jpademo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="product")
public class Product {
		
		@Id
		@Column(name="product_code")
		private String productCode;
		
		
		@Column(name="prod_desc",nullable = false)
		private String prodDesc;
		
		@Column(name="category_code",nullable = false)
		private String categoryCode;
		
		@Column(name="price",nullable = false)
		private double price;
		
		@Column(name="qty_on_hand",nullable = false)
		private int qtyOnHand;

		public String getProductCode() {
			return productCode;
		}

		public void setProductCode(String productCode) {
			this.productCode = productCode;
		}

		public String getProdDesc() {
			return prodDesc;
		}

		public void setProdDesc(String prodDesc) {
			this.prodDesc = prodDesc;
		}

		public String getCategoryCode() {
			return categoryCode;
		}

		public void setCategoryCode(String categoryCode) {
			this.categoryCode = categoryCode;
		}

		public double getPrice() {
			return price;
		}

		public void setPrice(double price) {
			this.price = price;
		}

		public int getQtyOnHand() {
			return qtyOnHand;
		}

		public void setQtyOnHand(int qtyOnHand) {
			this.qtyOnHand = qtyOnHand;
		}

		public Product(String productCode, String prodDesc, String categoryCode, double price, int qtyOnHand) {
			super();
			this.productCode = productCode;
			this.prodDesc = prodDesc;
			this.categoryCode = categoryCode;
			this.price = price;
			this.qtyOnHand = qtyOnHand;
		}

		public Product() {
			super();
			// TODO Auto-generated constructor stub
		}

		@Override
		public String toString() {
			return "Product [productCode=" + productCode + ", prodDesc=" + prodDesc + ", categoryCode=" + categoryCode
					+ ", price=" + price + ", qtyOnHand=" + qtyOnHand + "]";
		}

		
		
		
		
		
		

}

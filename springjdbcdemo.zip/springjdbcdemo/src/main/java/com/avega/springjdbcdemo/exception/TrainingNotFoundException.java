package com.avega.springjdbcdemo.exception;

public class TrainingNotFoundException extends Exception{
	
public TrainingNotFoundException() {
		
	}
	
	public TrainingNotFoundException(String message) {
		super(message);
	}

}

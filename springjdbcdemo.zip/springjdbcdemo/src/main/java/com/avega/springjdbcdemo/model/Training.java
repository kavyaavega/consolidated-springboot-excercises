package com.avega.springjdbcdemo.model;

import java.time.LocalDate;
import java.util.Objects;

public class Training {
	
	private int id;
	
	private String description;
	
	private LocalDate startDate;
	
	private LocalDate endDate;
	
	private int requestor_id;
	
	private int traineeEmployee;
	
	private int skillId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public int getRequestor_id() {
		return requestor_id;
	}

	public void setRequestor_id(int requestor_id) {
		this.requestor_id = requestor_id;
	}

	public int getTraineeEmployee() {
		return traineeEmployee;
	}

	public void setTraineeEmployee(int traineeEmployee) {
		this.traineeEmployee = traineeEmployee;
	}

	public int getSkillId() {
		return skillId;
	}

	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}

	public Training(int id, String description, LocalDate startDate, LocalDate endDate, int requestor_id,
			int traineeEmployee, int skillId) {
		super();
		this.id = id;
		this.description = description;
		this.startDate = startDate;
		this.endDate = endDate;
		this.requestor_id = requestor_id;
		this.traineeEmployee = traineeEmployee;
		this.skillId = skillId;
	}

	public Training() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Training [id=" + id + ", description=" + description + ", startDate=" + startDate + ", endDate="
				+ endDate + ", requestor_id=" + requestor_id + ", traineeEmployee=" + traineeEmployee + ", skillId="
				+ skillId + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Training other = (Training) obj;
		return id == other.id;
	}
	
	
	
	
	

}

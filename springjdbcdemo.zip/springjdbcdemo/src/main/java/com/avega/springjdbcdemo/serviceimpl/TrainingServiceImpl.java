package com.avega.springjdbcdemo.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.avega.springjdbcdemo.dao.TrainingDao;
import com.avega.springjdbcdemo.exception.TrainingNotFoundException;
import com.avega.springjdbcdemo.model.Training;
import com.avega.springjdbcdemo.service.TrainingService;

@Service
public class TrainingServiceImpl implements TrainingService {
	
	TrainingDao trainingDao;
	
	@Autowired
	public TrainingServiceImpl(TrainingDao trainingDao) {
		this.trainingDao=trainingDao;
	}

	@Override
	public List<Training> findAllTrainingDetails() {
		return trainingDao.getAllTrainingDetails();
	}

	/*@Override
	public Optional<Training> findTrainingById(int id) throws TrainingNotFoundException {
		return trainingDao.getTrainingDetailById(id);
	}*/

	@Override
	public int createTraining(Training training) {
		return trainingDao.addTraining(training);
	}

	@Override
	public int editTraining(Training training) {
		return trainingDao.updateTraining(training);
	}

	@Override
	public Training findTrainingByid(int id) {
		Training training =null;
		try {
			training=trainingDao.getTrainingByid(id);
		}
		catch(TrainingNotFoundException ex) {
			ex.printStackTrace();
		}
		return training;
	}

}

package com.avega.jparepository.demo.service;

import java.util.List;
import java.util.Optional;
import com.avega.jparepository.demo.model.Role;

public interface RoleService {
	List<Role> findAll();
	Role addRole(Role role);
	public void deleteRole(Role role);
	public void updateRole(Role role);
	public Optional<Role> findByRoleId(String roleId);
	

}

package com.avega.springjdbcdemo.daoimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.avega.springjdbcdemo.dao.TrainingDao;
import com.avega.springjdbcdemo.exception.TrainingNotFoundException;
import com.avega.springjdbcdemo.mapper.TrainingMapper;
import com.avega.springjdbcdemo.model.Training;


@Repository
public class TrainingDaoImpl implements TrainingDao{
	
	JdbcTemplate jdbcTemplate;
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	
	public TrainingDaoImpl(JdbcTemplate jdbcTemplate,NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		this.jdbcTemplate=jdbcTemplate;
		this.namedParameterJdbcTemplate=namedParameterJdbcTemplate;
	}

	@Override
	public List<Training> getAllTrainingDetails() {
		String SQL="SELECT id,description,start_date,end_date,requestor_id,trainee_employee_id,skill_id from training ";
		List<Training> training=this.jdbcTemplate.query(SQL, new TrainingMapper());

		return training;
	}

	/*@Override
	public Optional<Training> getTrainingDetailById(int id) throws TrainingNotFoundException {
		
		
		String SQL="SELECT id,description,start_date,end_date,requestor_id,trainee_employee_id,skill_id from training where id=?";
		Training training=this.jdbcTemplate.queryForObject(SQL,new Object[]{id},new TrainingMapper());
		return Optional.of(training);
	}*/

	@Override
	public int addTraining(Training training) {
		String SQL="insert into training(id,description,start_date,end_date,requestor_id,trainee_employee_id,skill_id ) values(?,?,?,?,?,?,?)";
		int result =this.jdbcTemplate.update(SQL, training.getId(),training.getDescription(),training.getStartDate(),training.getEndDate(),training.getRequestor_id(),training.getTraineeEmployee(),training.getSkillId());
		return result;
	}

	@Override
	public int updateTraining(Training training) {
		String SQL="update training set description=?,start_date=?,end_date=?,requestor_id=?,trainee_employee_id=?,skill_id=? where id=?"; 
		int result =this.jdbcTemplate.update(SQL, training.getDescription(),training.getStartDate(),training.getEndDate(),training.getRequestor_id(),training.getTraineeEmployee(),training.getSkillId(),training.getId());
		return result;
		
	}

	@Override
	public Training getTrainingByid(int id) throws TrainingNotFoundException {
		List<Training> trainings = getAllTrainingDetails();
		Training training= null;
		for(Training trainingfromlist:trainings)
		{
			if(trainingfromlist.getId() == id) {
				training=trainingfromlist;
				System.out.println(training);
				break;
				
			}
		}
		if(training == null) {
			throw new TrainingNotFoundException();
		}
		return training;	
	}

}

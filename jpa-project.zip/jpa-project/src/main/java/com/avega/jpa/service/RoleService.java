package com.avega.jpa.service;

import java.util.List;
import java.util.Optional;

import com.avega.jpa.entity.Employee;
import com.avega.jpa.entity.Role;

public interface RoleService {

	List<Role> findAllRoles();

	Optional<Role> findByRoleId(String roleId);

	Role addRole(Role role);

	void updateRole(Role role);

	void deleteRole(Role role);

}

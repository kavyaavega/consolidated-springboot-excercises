package com.avega.jpamapping.model;



import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Table(name="allocation")
public class Allocation {
	@Id
	private String allocationId;
	
	@ManyToOne
	private Training training;
	
	@ManyToOne
	@JoinTable(name = "employees_allocation",
	joinColumns = @JoinColumn(referencedColumnName = "allocationId"),
	inverseJoinColumns = @JoinColumn(referencedColumnName = "emp_id"))
	private Employee employee;

	private String status;
	
	private int score;

	private String remarks;
	
	@OneToOne
	private Employee allocatedBy;


	
	

}

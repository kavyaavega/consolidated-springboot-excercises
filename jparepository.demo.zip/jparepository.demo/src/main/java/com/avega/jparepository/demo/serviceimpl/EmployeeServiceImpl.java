package com.avega.jparepository.demo.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.avega.jparepository.demo.dao.EmployeeDao;
import com.avega.jparepository.demo.dao.RoleDao;
import com.avega.jparepository.demo.model.Employee;
import com.avega.jparepository.demo.model.Role;
import com.avega.jparepository.demo.service.EmployeeService;

@Service
public class EmployeeServiceImpl  implements EmployeeService{
	
EmployeeDao employeeDao;

RoleDao roleDao;
	
	@Autowired
	public EmployeeServiceImpl(EmployeeDao employeeDao,RoleDao roleDao) {
		this.employeeDao=employeeDao;
		this.roleDao=roleDao;
	}
	
	

	@Override
	public Employee addEmployee(Employee employee) {
		return employeeDao.save(employee);
	}

	@Override
	public void deleteEmployee(Employee employee) {
		 employeeDao.delete(employee);
	}

	@Override
	public void updateEmployee(Employee employee) {
		Optional<Employee> isEmployee = findByEmpId(employee.getEmpId());
		if(isEmployee.isPresent()) {
			isEmployee.get().setEmployeeName(employee.getEmployeeName());
			isEmployee.get().setDepartment(employee.getDepartment());
			isEmployee.get().setDesignation(employee.getDesignation());
			isEmployee.get().setDoj(employee.getDoj());
			addEmployee(isEmployee.get());
		}
	}

	@Override
	public Optional<Employee> findByEmpId(String empId) {
		return employeeDao.findById(empId);
		
	}

	@Override
	public void allocateEmployeeToRole(String empId, String roleId) {
           Optional<Employee> optionalemployee = findByEmpId(empId);
           if(optionalemployee.isPresent()) {
        	   Employee employee = optionalemployee.get();
        	   Optional<Role> optionalrole = this.roleDao.findById(roleId);
        	   if(optionalrole.isPresent()) {
        		   Role role = optionalrole.get();  
        		   List<Role> roles = employee.getRoles();
        		   roles.add(role);
        		   employee.setRoles(roles);
        		   employeeDao.save(employee); 
        	   }  
           }	
	}



	@Override
	public List<Employee> findAll() {
		return employeeDao.findAll();
	}
	
}

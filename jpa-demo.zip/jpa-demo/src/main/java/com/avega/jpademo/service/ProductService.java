package com.avega.jpademo.service;

import java.util.List;

import com.avega.jpademo.model.Product;

public interface ProductService {

	
	Product add(Product product);
	Product retriveByProductCode(String productCode);
	List<Product> findAllProducts();
	Product editProduct(Product product);
	boolean removeProduct(String productCode);
}

package com.avega.jpamapping.dao;

public interface TrainingDao {

}

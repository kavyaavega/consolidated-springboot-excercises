package com.avega.springjdbcdemo;

import java.time.LocalDate;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import com.avega.springjdbcdemo.exception.TrainingNotFoundException;
import com.avega.springjdbcdemo.model.Training;
import com.avega.springjdbcdemo.service.TrainingService;
import com.avega.springjdbcdemo.serviceimpl.TrainingServiceImpl;

@SpringBootApplication
@EnableAspectJAutoProxy
public class SpringjdbcdemoApplication {

	public static void main(String[] args) throws TrainingNotFoundException {
		ApplicationContext ctn=SpringApplication.run(SpringjdbcdemoApplication.class, args);
		
		TrainingService service=(TrainingService) ctn.getBean(TrainingServiceImpl.class);
		//getAll
		List<Training> training=service.findAllTrainingDetails();
		training.forEach(System.out::println);
		
		//getbyid
		/*if(service.findTrainingById(105).isPresent())
		{
			System.out.println(service.findTrainingById(105).get());
		}*/
		
	//create
		/*Training tr=new Training(104,"python",LocalDate.of(2023,06,01),LocalDate.of(2023,07,30),11,12,400);
		  System.out.println(service.createTraining(tr));*/
		
		//update
		/*Training tr=new Training(104,"Js",LocalDate.of(2023,06,01),LocalDate.of(2023,07,30),11,12,400);
		  System.out.println(service.editTraining(tr));*/
		
		/*service.findTrainingByid(105);
		System.out.println(service.findTrainingByid(105));*/
		
	}

}

package com.avega.jpademo;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.avega.jpademo.model.Product;
import com.avega.jpademo.service.ProductService;
import com.avega.jpademo.serviceimpl.ProductServiceImpl;




@SpringBootApplication
public class JpaDemoApplication {

	public static void main(String[] args) {
		
   ApplicationContext ctn=SpringApplication.run(JpaDemoApplication.class, args);
		
		ProductService service=(ProductService) ctn.getBean(ProductServiceImpl.class);
		
		/*System.out.println(">>>>>>>>>>>>find a product>>>>>>>>>>>");
		System.out.println(service.retriveByProductCode("PR2209"));*/
		
		/*System.out.println(">>>>>>>>>>>>find all product>>>>>>>>>>>");
		List<Product> products=service.findAllProducts();
		products.forEach(System.out::println);*/
		
		/*System.out.println(">>>>>>>>>>>>Add a product>>>>>>>>>>>");
		Product pr = new Product("PR2210","Samsung galaxy","CT05",25000,1);
		System.out.println(service.add(pr));*/
		
		/*System.out.println(">>>>>>>>>>>>Update a product>>>>>>>>>>>");
		Product pr = new Product("PR2210","Samsung galaxy","CT05",30000,1);
		System.out.println(service.editProduct(pr));*/
		
		/*System.out.println(">>>>>>>>>>>>delete products>>>>>>>>>>>");
		System.out.println(service.removeProduct("PR2210"));*/
			
		
	}

}

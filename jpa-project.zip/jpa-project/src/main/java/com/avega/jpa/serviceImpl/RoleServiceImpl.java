package com.avega.jpa.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.avega.jpa.dao.RoleDao;
import com.avega.jpa.entity.Role;
import com.avega.jpa.service.RoleService;

@Service
public class RoleServiceImpl implements RoleService {

	private RoleDao roleDao;

	public RoleServiceImpl(RoleDao roleDao) {
		this.roleDao = roleDao;
	}

	@Override
	public List<Role> findAllRoles() {
		return roleDao.findAll();
	}

	@Override
	public Optional<Role> findByRoleId(String roleId) {
		return roleDao.findById(roleId);
	}

	@Override
	public Role addRole(Role role) {
		return roleDao.save(role);
	}

	@Override
	public void updateRole(Role role) {
		Optional<Role> isRole = findByRoleId(role.getRoleId());
		if (isRole.isPresent()) {
			isRole.get().setRoleName(role.getRoleName());
			addRole(role);
		}
	}

	@Override
	public void deleteRole(Role role) {
		roleDao.delete(role);
	}

}

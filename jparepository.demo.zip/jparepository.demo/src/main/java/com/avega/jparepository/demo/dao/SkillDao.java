package com.avega.jparepository.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.avega.jparepository.demo.model.Skill;

public interface SkillDao extends JpaRepository<Skill, String> {

}

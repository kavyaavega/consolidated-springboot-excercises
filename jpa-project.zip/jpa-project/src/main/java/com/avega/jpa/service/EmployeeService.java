package com.avega.jpa.service;

import java.util.List;
import java.util.Optional;

import com.avega.jpa.entity.Employee;
import com.avega.jpa.entity.Role;

public interface EmployeeService {
	
	List<Employee> findAllEmployees();
	
	Optional<Employee> findByEmployeeId(String employeeId);
	
	Employee addEmployee(Employee employee);
	
	void updateEmployee(Employee employee);
	
	void deleteEmployee(Employee employee);
	
	void allocateRoleForEmployee(String employeeId, String roleId);
	

}

package com.avega.springmvc.student.model;

@Controller
public class StudentAdmissionController {
	
	@RequestMapping(value="/admissionForm.html", method =RequestMethod.GET)
	public ModelAndView getAdmissionForm() {
		ModelAndView model1 = new ModelAndView("AdmissionForm");
		return  model1;
	}

}

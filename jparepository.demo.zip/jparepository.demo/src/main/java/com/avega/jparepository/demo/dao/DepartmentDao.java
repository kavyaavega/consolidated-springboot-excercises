package com.avega.jparepository.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.avega.jparepository.demo.model.Department;

public interface DepartmentDao extends JpaRepository<Department, String> {

}

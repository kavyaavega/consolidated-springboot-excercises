package com.example.mvcapp.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.mvcapp.model.Client;
import com.example.mvcapp.model.Roles;

@Service(value="customUserDetails")
public class CustomUserDetailsService implements UserDetailsService {

	@Autowired
	ClientUserService clientUserService;
	
	public ClientUserService getClientUserService() {
		return clientUserService;
	}

	public void setClientUserService(ClientUserService clientUserService) {
		this.clientUserService = clientUserService;
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		
		List<Client> userData = clientUserService.findByPhoneNumber(username);
		if(userData == null) {
			System.out.println("User Not Found");
			return null;
		}
		Client data = userData.get(0);
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		return new User(data.getPhone(), encoder.encode(data.getPassword()), true, true, true, true, getGrantedAuthorities(data));
	}
	
	private List<GrantedAuthority> getGrantedAuthorities(Client userData){
		List<GrantedAuthority> roles = new ArrayList<GrantedAuthority>();
		for(Roles userRole : userData.getRoles()){
			roles.add(new SimpleGrantedAuthority( userRole.getRoleType()));
		}
		return roles;
	}

}

package com.avega.jpamapping.serviceimpl;

public class SkillServiceImpl {

}

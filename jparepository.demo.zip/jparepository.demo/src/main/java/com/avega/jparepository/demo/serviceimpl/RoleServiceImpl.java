package com.avega.jparepository.demo.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.avega.jparepository.demo.dao.RoleDao;
import com.avega.jparepository.demo.model.Role;
import com.avega.jparepository.demo.service.RoleService;

@Service
public class RoleServiceImpl  implements RoleService{
	
	RoleDao roleDao;
	
	@Autowired
	public RoleServiceImpl(RoleDao roleDao) {
		this.roleDao=roleDao;
	}

	@Override
	public Role addRole(Role role) {
		return roleDao.save(role);
	}

	@Override
	public void deleteRole(Role role) {
		roleDao.delete(role);
	}

	@Override
	public void updateRole(Role role) {
		Optional<Role> isRole = findByRoleId(role.getRoleId());
		if(isRole.isPresent()) {
			isRole.get().setRoleName(role.getRoleName());
			addRole(isRole.get());
		}
		
	}

	@Override
	public Optional<Role> findByRoleId(String roleId) {
		return roleDao.findById(roleId);
	}

	@Override
	public List<Role> findAll() {
		return roleDao.findAll();
	}

}

package com.avega.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}


package com.avega.jparepository.demo.dao;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Response<T> {
	
	private String statusCode;
	private String stausMessage;
	private T data;

}

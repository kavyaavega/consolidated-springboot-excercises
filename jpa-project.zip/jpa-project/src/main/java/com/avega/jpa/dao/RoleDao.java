package com.avega.jpa.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.avega.jpa.entity.Role;

public interface RoleDao extends JpaRepository<Role, String> {

}
